# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import os
import codecs
import json
import csv
from scrapy.exporters import JsonItemExporter
from openpyxl import Workbook
class JsonPipeline(object):
	# 使用FeedJsonItenExporter保存数据
    def __init__(self):
        self.file = open('weather1.json','wb')
        self.exporter = JsonItemExporter(self.file,ensure_ascii =False)
        self.exporter.start_exporting()

    def process_item(self,item,spider):
        print('Write')
        self.exporter.export_item(item)
        return item

    def close_spider(self,spider):
        print('Close')
        self.exporter.finish_exporting()
        self.file.close()

		
class TxtPipeline(object):
	def process_item(self, item, spider):
		#获取当前工作目录
		base_dir = os.getcwd()
		filename = base_dir + 'weather.txt'
		print('创建Txt')
		#从内存以追加方式打开文件,并写入对应的数据
		with open(filename, 'a') as f:
			f.write('城市:' + item['city'] + ' ')
			f.write(item['city_addition'] + ' ')
			f.write(item['city_addition2'] + '\n')
			f.write('天气:' + item['weather'] + '\n')
			f.write('温度:' + item['temperatureMin'] + '~' + item['temperatureMax'] + '℃\n')
	
class ExcelPipeline(object):
	#创建EXCEL,填写表头
	def __init__(self):
		self.wb = Workbook()
		self.ws = self.wb.active
		#设置表头
		self.ws.append(['省', '市', '县(乡)', '日期', '天气', '最高温', '最低温'])
	
	def process_item(self, item, spider):
		line = [item['city'], item['city_addition'], item['city_addition2'], item['data'], item['weather'], item['temperatureMax'], item['temperatureMin']]
		self.ws.append(line) #将数据以行的形式添加仅xlsx中
		self.wb.save('weather.xlsx')
		return item
	'''def process_item(self, item, spider):
		base_dir = os.getcwd()
		filename = base_dir + 'weather.csv'
		print('创建EXCEL')
		with open(filename,'w') as f:
			fieldnames = ['省','市', '县(乡)', '天气', '日期', '最高温','最低温'] # 定义字段的名称
			writer = csv.DictWriter(f,fieldnames=fieldnames) # 初始化一个字典对象
			write.writeheader() # 调用writeheader()方法写入头信息
			# 传入相应的字典数据
			write.writerow(dict(item))
	'''
