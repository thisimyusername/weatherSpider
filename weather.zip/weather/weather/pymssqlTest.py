import pymssql


def conn():
    connect = pymssql.connect('(local)', 'sa', 'password1633', 'test')
    if connect:
        print("连接成功!")
    return connect


def insert():
    #sql_str = "insert into C_test (id, name, sex)values(1002, '张姒', '女')"
    conn2 = conn()
    cursor = conn2.cursor()
    cursor.execute_query('select * from users where username = %s', 'Jane Doe')
    row = cursor.fetchone()
    while row:
        print("ID=%d, Name=%s" % (row[0], row[1]))
        row = cursor.fetchone()


if __name__ == '__main__':
    insert()
