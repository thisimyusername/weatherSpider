# -*- coding: utf-8 -*-
import os
import json
from pyecharts import Bar

# 柱状图(2维)
def DrawBar(title, data, savepath='./results'):

	if not os.path.exists(savepath):
		os.mkdir(savepath)
	bar = Bar(title)
	attrs = [i for i, j in data.items()]
	values = [j for i, j in data.items()]
	bar.add('城市', attrs, values, mark_point=["min", "max"])
	bar.render(os.path.join(savepath, '%s.html' % title))
	
if __name__ == '__main__':
	#F:\ScrapyProject\anjukeSpider\anjuke.json
	#F:\ScrapyProject\weather\weather\weather.json
	# with open(r'F:\ScrapyProject\weather\weather\we1.json', 'r', encoding="utf-8") as fi:
	with open(r'F:\ScrapyProject\weather\weather\we1.txt', 'r', encoding="utf-8") as fi:
		print(fi.read())
		# print(type(fi.read()))
		data = json.loads(fi.read())
		print("success")
	for d in data:
		data2 = []
		del d['city']
		if d['city_addition2'] != '':
			del d['city_addition']
		del d['data']
		del d['weather']
		del d['temperatureMax']
		data2.append(d)
	DrawBar(title='部分地区最低气温柱状图', data=data2, savepath='./results')