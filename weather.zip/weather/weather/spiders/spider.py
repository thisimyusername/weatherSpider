import scrapy
from weather.items import WeatherItem
from scrapy.spiders import Rule, CrawlSpider
from scrapy.linkextractors import LinkExtractor
class Spider(CrawlSpider):
	name = 'weatherSpider'
	#allowed_domains = "www.weather.com.cn"
	start_urls = [
		"http://www.weather.com.cn/weather1d/101020100.shtml#search"
	]
	rules = (
		Rule(LinkExtractor(allow=('http://www.weather.com.cn/weather1d/101\d{6}.shtml#around2')), follow=False, callback='parse_item'),
	)
	
	
	#多页面爬取时需要自定义方法名称,不能用parse
	def parse_item(self, response):
		item = WeatherItem()
		item['city'] = response.xpath("//div[@class='crumbs fl']/a/text()").extract_first()
		city_addition = response.xpath("//div[@class='crumbs fl']/span[2]/text()").extract_first()
		if city_addition == '>':
			item['city_addition'] = response.xpath("//div[@class='crumbs fl']/a[2]/text()").extract_first()
		else:
			item['city_addition'] = response.xpath("//div[@class='crumbs fl']/span[2]/text()").extract_first()
		item['city_addition2'] = response.xpath("//div[@class='crumbs fl']/span[3]/text()").extract_first()
		weatherData = response.xpath("//div[@class='today clearfix']/input[1]/@value").extract_first()
		item['data'] = weatherData[0:6]
		item['weather'] = response.xpath("//p[@class='wea']/text()").extract_first()
		item['temperatureMax'] = response.xpath("//ul[@class='clearfix']/li[1]/p[@class='tem']/span[1]/text()").extract_first()
		item['temperatureMin'] = response.xpath("//ul[@class='clearfix']/li[2]/p[@class='tem']/span[1]/text()").extract_first()
		yield item